<?php
require_once 'db.php';

$message = '';
$error = '';

$plans = $conn->query("SELECT PlanID, PlanName, DurationDays, Price FROM membership_plan ORDER BY Price ASC")->fetch_all(MYSQLI_ASSOC);
$staffList = $conn->query("SELECT StaffID, FirstName, LastName, StaffType FROM gym_staff ORDER BY StaffID ASC")->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = trim($_POST['FirstName'] ?? '');
    $lastName = trim($_POST['LastName'] ?? '');
    $dob = trim($_POST['DateOfBirth'] ?? '');
    $phone = trim($_POST['PhoneNumber'] ?? '');

    $contactName = trim($_POST['ContactName'] ?? '');
    $relationship = trim($_POST['Relationship'] ?? '');
    $contactPhone = trim($_POST['ContactPhone'] ?? '');

    $planId = trim($_POST['PlanID'] ?? '');
    $staffId = trim($_POST['StaffID'] ?? '');
    $amount = (float)($_POST['Amount'] ?? 0);
    $paymentMethod = trim($_POST['PaymentMethod'] ?? 'Cash');
    $refNumber = trim($_POST['ReferenceNumber'] ?? '');

    $stmtPlan = $conn->prepare("SELECT PlanID, DurationDays, Price FROM membership_plan WHERE PlanID = ?");
    $stmtPlan->bind_param("s", $planId);
    $stmtPlan->execute();
    $planData = $stmtPlan->get_result()->fetch_assoc();
    $stmtPlan->close();

    if (
        !$firstName || !$lastName || !$dob || !$phone ||
        !$contactName || !$relationship || !$contactPhone ||
        !$planData || !$staffId || $amount <= 0
    ) {
        $error = "Please fill in all required fields and enter a valid payment amount.";
    } else {
        $days = (int)$planData['DurationDays'];
        if ($days <= 0) {
            $days = 30;
        }

        $startDate = date('Y-m-d');
        $endDate = date('Y-m-d', strtotime("+{$days} days"));
        $paymentDate = date('Y-m-d');
        $paymentTime = date('H:i:s');
        $subStatus = 'Active';

        if ($refNumber === '') {
            $refNumber = 'REF-' . date('YmdHis') . '-' . rand(100, 999);
        }

        $conn->begin_transaction();

        try {
            $memberId = nextPrefixedId($conn, 'gym_member', 'MemberID', 'MEM', 101);
            $contactId = nextPrefixedId($conn, 'emergency_contact', 'ContactID', 'EMG', 401);
            $subscriptionId = nextPrefixedId($conn, 'subscription', 'SubscriptionID', 'SUB', 1001);

            $resPayId = $conn->query("SELECT COALESCE(MAX(PaymentID), 5000) + 1 AS next_id FROM payment");
            $paymentId = (int)$resPayId->fetch_assoc()['next_id'];

            // 1. gym_member
            $stmtMember = $conn->prepare("
                INSERT INTO gym_member (MemberID, FirstName, LastName, DateOfBirth, PhoneNumber, is_archived)
                VALUES (?, ?, ?, ?, ?, 0)
            ");
            $stmtMember->bind_param("sssss", $memberId, $firstName, $lastName, $dob, $phone);
            $stmtMember->execute();
            $stmtMember->close();

            // 2. emergency_contact
            $stmtContact = $conn->prepare("
                INSERT INTO emergency_contact (ContactID, MemberID, ContactName, Relationship, PhoneNumber)
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmtContact->bind_param("sssss", $contactId, $memberId, $contactName, $relationship, $contactPhone);
            $stmtContact->execute();
            $stmtContact->close();

            // 3. subscription
            $stmtSub = $conn->prepare("
                INSERT INTO subscription (SubscriptionID, MemberID, PlanID, StartDate, EndDate, Status)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmtSub->bind_param("ssssss", $subscriptionId, $memberId, $planId, $startDate, $endDate, $subStatus);
            $stmtSub->execute();
            $stmtSub->close();

            // 4. payment
            $stmtPay = $conn->prepare("
                INSERT INTO payment (PaymentID, MemberID, StaffID, SubscriptionID, Amount, PaymentDate, PaymentTime, PaymentMethod, ReferenceNumber)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmtPay->bind_param(
                "isssdssss",
                $paymentId,
                $memberId,
                $staffId,
                $subscriptionId,
                $amount,
                $paymentDate,
                $paymentTime,
                $paymentMethod,
                $refNumber
            );
            $stmtPay->execute();
            $stmtPay->close();

            $conn->commit();
            $message = "Registered {$firstName} {$lastName} ({$memberId}) with Subscription {$subscriptionId} and Payment #{$paymentId}.";
        } catch (Exception $e) {
            $conn->rollback();
            $error = "Transaction failed and was rolled back: " . $e->getMessage();
        }
    }
}
?>