<?php
require_once 'db.php';

$feedback = '';

// Soft Delete (move to Archives)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'soft_delete') {
    $memberId = trim($_POST['MemberID'] ?? '');
    $stmt = $conn->prepare("UPDATE gym_member SET is_archived = 1 WHERE MemberID = ?");
    $stmt->bind_param("s", $memberId);
    if ($stmt->execute()) {
        $feedback = "Member {$memberId} moved to Archives.";
    }
    $stmt->close();
}

// Update Member & Emergency Contact
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_member') {
    $memberId = trim($_POST['MemberID'] ?? '');
    $firstName = trim($_POST['FirstName'] ?? '');
    $lastName = trim($_POST['LastName'] ?? '');
    $dob = trim($_POST['DateOfBirth'] ?? '');
    $phone = trim($_POST['PhoneNumber'] ?? '');

    $contactId = trim($_POST['ContactID'] ?? '');
    $contactName = trim($_POST['ContactName'] ?? '');
    $relationship = trim($_POST['Relationship'] ?? '');
    $contactPhone = trim($_POST['ContactPhone'] ?? '');

    $conn->begin_transaction();
    try {
        $stmt1 = $conn->prepare("
            UPDATE gym_member
            SET FirstName = ?, LastName = ?, DateOfBirth = ?, PhoneNumber = ?
            WHERE MemberID = ?
        ");
        $stmt1->bind_param("sssss", $firstName, $lastName, $dob, $phone, $memberId);
        $stmt1->execute();
        $stmt1->close();

        if ($contactId !== '') {
            $stmt2 = $conn->prepare("
                UPDATE emergency_contact
                SET ContactName = ?, Relationship = ?, PhoneNumber = ?
                WHERE ContactID = ? AND MemberID = ?
            ");
            $stmt2->bind_param("sssss", $contactName, $relationship, $contactPhone, $contactId, $memberId);
            $stmt2->execute();
            $stmt2->close();
        } else {
            $newContactId = nextPrefixedId($conn, 'emergency_contact', 'ContactID', 'EMG', 401);
            $stmt2 = $conn->prepare("
                INSERT INTO emergency_contact (ContactID, MemberID, ContactName, Relationship, PhoneNumber)
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt2->bind_param("sssss", $newContactId, $memberId, $contactName, $relationship, $contactPhone);
            $stmt2->execute();
            $stmt2->close();
        }

        $conn->commit();
        $feedback = "Updated member {$memberId} and emergency contact.";
    } catch (Exception $e) {
        $conn->rollback();
        $feedback = "Update failed: " . $e->getMessage();
    }
}

// Search active (non-archived) members with latest subscription & emergency contact
$search = trim($_GET['q'] ?? '');
$baseQuery = "
    SELECT
        m.MemberID, m.FirstName, m.LastName, m.DateOfBirth, m.PhoneNumber,
        ec.ContactID, ec.ContactName, ec.Relationship, ec.PhoneNumber AS ContactPhone,
        s.Status AS SubStatus, s.EndDate,
        mp.PlanName
    FROM gym_member m
    LEFT JOIN emergency_contact ec ON m.MemberID = ec.MemberID
    LEFT JOIN subscription s ON s.SubscriptionID = (
        SELECT s2.SubscriptionID
        FROM subscription s2
        WHERE s2.MemberID = m.MemberID
        ORDER BY s2.StartDate DESC, s2.SubscriptionID DESC
        LIMIT 1
    )
    LEFT JOIN membership_plan mp ON s.PlanID = mp.PlanID
    WHERE m.is_archived = 0
";

if ($search !== '') {
    $stmt = $conn->prepare($baseQuery . "
        AND (
            m.MemberID LIKE ?
            OR m.FirstName LIKE ?
            OR m.LastName LIKE ?
            OR CONCAT(m.FirstName, ' ', m.LastName) LIKE ?
            OR m.PhoneNumber LIKE ?
        )
        ORDER BY m.MemberID ASC
    ");
    $like = "%{$search}%";
    $stmt->bind_param("sssss", $like, $like, $like, $like, $like);
} else {
    $stmt = $conn->prepare($baseQuery . " ORDER BY m.MemberID ASC");
}

$stmt->execute();
$members = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Load member for editing if requested
$editMember = null;
if (isset($_GET['edit']) && $_GET['edit'] !== '') {
    $editId = trim($_GET['edit']);
    $stmtEdit = $conn->prepare("
        SELECT m.*, ec.ContactID, ec.ContactName, ec.Relationship, ec.PhoneNumber AS ContactPhone
        FROM gym_member m
        LEFT JOIN emergency_contact ec ON m.MemberID = ec.MemberID
        WHERE m.MemberID = ? AND m.is_archived = 0
    ");
    $stmtEdit->bind_param("s", $editId);
    $stmtEdit->execute();
    $editMember = $stmtEdit->get_result()->fetch_assoc();
    $stmtEdit->close();
}
?>