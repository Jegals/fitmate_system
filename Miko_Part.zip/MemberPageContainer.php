<?php
require_once 'db.php';

$memberId = trim($_GET['id'] ?? '');
$tab = $_GET['tab'] ?? 'overview';
$allowedTabs = ['overview', 'payments', 'programs', 'progress'];
if (!in_array($tab, $allowedTabs, true)) {
    $tab = 'overview';
}

$stmt = $conn->prepare("
    SELECT m.*, ec.ContactName, ec.Relationship, ec.PhoneNumber AS ContactPhone
    FROM gym_member m
    LEFT JOIN emergency_contact ec ON m.MemberID = ec.MemberID
    WHERE m.MemberID = ?
");
$stmt->bind_param("s", $memberId);
$stmt->execute();
$member = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$member) {
    die("Member not found.");
}
?>